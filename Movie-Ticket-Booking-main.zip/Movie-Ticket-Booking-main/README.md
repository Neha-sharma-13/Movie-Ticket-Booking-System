# Movie-Ticket-Booking
How to create Movie Ticket Booking System in C++ using MySQL & OOP.
If you want to watch the video for better understanding about the given code then click on the give link:
https://youtu.be/Yb6PQ2D8cHY
 
